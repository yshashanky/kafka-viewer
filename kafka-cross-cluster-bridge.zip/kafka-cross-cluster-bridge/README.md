# Kafka Cross-Cluster Bridge

Java 21 / Spring Boot implementation for consuming String JSON from one Kafka cluster,
transforming it to an Avro `GenericRecord`, and publishing it to another Kafka cluster.

## Delivery semantics

The listener uses manual immediate acknowledgment. The destination send is awaited on the
listener thread; the source offset is acknowledged only after the destination broker confirms
the write. This provides **at-least-once** delivery across two independent Kafka clusters.

There is no atomic transaction spanning both clusters. A process crash after the destination
write succeeds but before the source offset commit can cause the source record to be replayed
and published again. Destination processing should therefore be idempotent/deduplication-aware.

## Concurrency

`app.kafka.consumer.concurrency` controls the number of consumer threads. Effective parallelism
is bounded by the number of partitions in the source topic. Start near the partition count and
tune from observed processing latency, consumer lag, CPU, broker throughput, and downstream
capacity.

## Transformation

`MessageTransformationService` is the single business transformation entry point. It currently:

1. Parses arbitrary JSON into a Jackson `JsonNode`.
2. Produces a flattened `Map<String, Object>` through `JsonFlattener`.
3. Leaves destination `GenericRecord` construction as a deliberate TODO because the destination
   Avro schema/business mapping was not provided.

Array indexes are preserved, e.g. `consumers[0].id`.

## SSL

Kafka broker SSL settings are shared by source consumer and destination producer. Only their
bootstrap servers and client-specific settings are separate. Secrets are parameterized through
environment variables in `application.properties`; do not commit actual passwords.

## Failure policy

The default source error handler retries failed records indefinitely. This is intentional to avoid
silently skipping data before a retry/DLQ design has been agreed. A permanently invalid record can
therefore block its partition. Replace this with an explicit retry/DLQ policy when that behavior is
defined.

## Logging

Application logging uses the SLF4J API (`org.slf4j.Logger` / `LoggerFactory`). The project pins
SLF4J 2.0.20 while keeping Spring Boot's managed logging provider. Payload bodies and SSL secrets
are not written to logs by the bridge code.

## Unit tests and coverage

Tests are under `src/test/java` and cover:

- shared SSL property propagation;
- source consumer and destination producer factory configuration;
- manual acknowledgment and at-least-once ordering;
- no source acknowledgment when transformation or destination publishing fails;
- producer success, timeout, execution failure, and interrupted-thread handling;
- generic JSON parsing, invalid/blank input, and maximum nesting depth;
- recursive flattening of nested objects, arrays, nulls, numbers, booleans, strings, binary
  values, empty structures, and root scalar values;
- transformation orchestration up to the intentionally unfinished destination `GenericRecord`
  mapping method;
- application bootstrap delegation.

JaCoCo is configured in `pom.xml`. `mvn verify` enforces a minimum **95% line coverage** for the
implemented project code. The schema/business-specific `GenericRecord` mapping remains the only
intentional implementation placeholder.

Run:

```bash
mvn clean verify
```

The HTML coverage report is generated at `target/site/jacoco/index.html`.
