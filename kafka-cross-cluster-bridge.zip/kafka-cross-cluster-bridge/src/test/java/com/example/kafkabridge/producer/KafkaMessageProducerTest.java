package com.example.kafkabridge.producer;

import com.example.kafkabridge.TestFixtures;
import com.example.kafkabridge.config.KafkaBridgeProperties;
import com.example.kafkabridge.exception.KafkaPublishException;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class KafkaMessageProducerTest {

    @AfterEach
    void clearInterruptedFlag() {
        Thread.interrupted();
    }

    @Test
    void returnsBrokerMetadataAfterSuccessfulPublish() throws Exception {
        KafkaTemplate<String, GenericRecord> template = mock(KafkaTemplate.class);
        KafkaBridgeProperties properties = TestFixtures.properties();
        GenericRecord record = mock(GenericRecord.class);
        RecordMetadata metadata = mock(RecordMetadata.class);
        SendResult<String, GenericRecord> sendResult = mock(SendResult.class);
        CompletableFuture<SendResult<String, GenericRecord>> future =
                CompletableFuture.completedFuture(sendResult);

        when(sendResult.getRecordMetadata()).thenReturn(metadata);
        when(template.send("destination-topic", "key-1", record)).thenReturn(future);

        KafkaMessageProducer producer = new KafkaMessageProducer(template, properties);

        assertThat(producer.publish("key-1", record)).isSameAs(metadata);
        verify(template).send("destination-topic", "key-1", record);
    }

    @Test
    void wrapsExecutionFailure() {
        KafkaTemplate<String, GenericRecord> template = mock(KafkaTemplate.class);
        GenericRecord record = mock(GenericRecord.class);
        CompletableFuture<SendResult<String, GenericRecord>> future = new CompletableFuture<>();
        future.completeExceptionally(new IllegalStateException("broker failure"));
        when(template.send("destination-topic", "key", record)).thenReturn(future);

        KafkaMessageProducer producer = new KafkaMessageProducer(template, TestFixtures.properties());

        assertThatThrownBy(() -> producer.publish("key", record))
                .isInstanceOf(KafkaPublishException.class)
                .hasMessage("Failed to publish to destination Kafka")
                .hasCauseInstanceOf(ExecutionException.class);
    }

    @Test
    void wrapsTimeoutFailure() throws Exception {
        KafkaTemplate<String, GenericRecord> template = mock(KafkaTemplate.class);
        GenericRecord record = mock(GenericRecord.class);
        @SuppressWarnings("unchecked")
        CompletableFuture<SendResult<String, GenericRecord>> future = mock(CompletableFuture.class);
        when(template.send("destination-topic", "key", record)).thenReturn(future);
        when(future.get(anyLong(), eq(TimeUnit.MILLISECONDS)))
                .thenThrow(new TimeoutException("timeout"));

        KafkaMessageProducer producer = new KafkaMessageProducer(template, TestFixtures.properties());

        assertThatThrownBy(() -> producer.publish("key", record))
                .isInstanceOf(KafkaPublishException.class)
                .hasMessage("Failed to publish to destination Kafka")
                .hasCauseInstanceOf(TimeoutException.class);
    }

    @Test
    void restoresInterruptStatusAndWrapsInterruptedFailure() throws Exception {
        KafkaTemplate<String, GenericRecord> template = mock(KafkaTemplate.class);
        GenericRecord record = mock(GenericRecord.class);
        @SuppressWarnings("unchecked")
        CompletableFuture<SendResult<String, GenericRecord>> future = mock(CompletableFuture.class);
        when(template.send("destination-topic", "key", record)).thenReturn(future);
        when(future.get(anyLong(), eq(TimeUnit.MILLISECONDS)))
                .thenThrow(new InterruptedException("interrupted"));

        KafkaMessageProducer producer = new KafkaMessageProducer(template, TestFixtures.properties());

        assertThatThrownBy(() -> producer.publish("key", record))
                .isInstanceOf(KafkaPublishException.class)
                .hasMessage("Interrupted while publishing to destination Kafka")
                .hasCauseInstanceOf(InterruptedException.class);

        assertThat(Thread.currentThread().isInterrupted()).isTrue();
    }
}
