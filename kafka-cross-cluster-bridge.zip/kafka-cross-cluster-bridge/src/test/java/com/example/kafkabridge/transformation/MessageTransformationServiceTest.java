package com.example.kafkabridge.transformation;

import com.example.kafkabridge.exception.MessageProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class MessageTransformationServiceTest {

    @Test
    void parsesAndFlattensBeforeReachingBusinessSpecificMappingPlaceholder() {
        JsonMessageParser parser = mock(JsonMessageParser.class);
        JsonFlattener flattener = mock(JsonFlattener.class);
        JsonNode source = mock(JsonNode.class);
        Map<String, Object> flattened = Map.of("id", "123");

        when(parser.parse("{\"id\":\"123\"}")).thenReturn(source);
        when(flattener.flatten(source)).thenReturn(flattened);

        MessageTransformationService service = new MessageTransformationService(parser, flattener);

        assertThatThrownBy(() -> service.transform("{\"id\":\"123\"}"))
                .isInstanceOf(MessageProcessingException.class)
                .hasMessage("Destination GenericRecord transformation is not implemented yet");

        verify(parser).parse("{\"id\":\"123\"}");
        verify(flattener).flatten(source);
    }
}
