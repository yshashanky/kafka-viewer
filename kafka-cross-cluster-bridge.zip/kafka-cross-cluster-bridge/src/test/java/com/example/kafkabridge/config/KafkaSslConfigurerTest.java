package com.example.kafkabridge.config;

import com.example.kafkabridge.TestFixtures;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaSslConfigurerTest {

    @Test
    void appliesAllSharedSslProperties() {
        KafkaSslConfigurer configurer = new KafkaSslConfigurer(TestFixtures.properties());
        Map<String, Object> target = new HashMap<>();

        configurer.applyTo(target);

        assertThat(target)
                .containsEntry(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL")
                .containsEntry(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/tmp/truststore.jks")
                .containsEntry(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "trust-password")
                .containsEntry(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS")
                .containsEntry(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "/tmp/keystore.jks")
                .containsEntry(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "key-password-store")
                .containsEntry(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "JKS")
                .containsEntry(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "private-key-password")
                .containsEntry(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "https");
    }
}
