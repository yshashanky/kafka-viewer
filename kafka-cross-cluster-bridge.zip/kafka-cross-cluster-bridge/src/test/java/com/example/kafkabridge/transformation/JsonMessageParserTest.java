package com.example.kafkabridge.transformation;

import com.example.kafkabridge.TestFixtures;
import com.example.kafkabridge.exception.MessageProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JsonMessageParserTest {

    private final JsonMessageParser parser = new JsonMessageParser(TestFixtures.properties());

    @Test
    void parsesValidDynamicJson() {
        JsonNode node = parser.parse("{\"id\":123,\"consumer\":{\"name\":\"abc\"}}");

        assertThat(node.get("id").asInt()).isEqualTo(123);
        assertThat(node.get("consumer").get("name").asText()).isEqualTo("abc");
    }

    @Test
    void rejectsNullBlankAndInvalidJson() {
        assertThatThrownBy(() -> parser.parse(null))
                .isInstanceOf(MessageProcessingException.class)
                .hasMessage("Source Kafka message is null or blank");

        assertThatThrownBy(() -> parser.parse("   "))
                .isInstanceOf(MessageProcessingException.class)
                .hasMessage("Source Kafka message is null or blank");

        assertThatThrownBy(() -> parser.parse("{bad-json"))
                .isInstanceOf(MessageProcessingException.class)
                .hasMessage("Source Kafka message is not valid JSON")
                .hasCauseInstanceOf(Exception.class);
    }

    @Test
    void enforcesConfiguredMaximumJsonDepth() {
        var properties = TestFixtures.properties();
        var shallowProperties = new com.example.kafkabridge.config.KafkaBridgeProperties(
                properties.ssl(),
                properties.consumer(),
                properties.producer(),
                properties.schemaRegistry(),
                new com.example.kafkabridge.config.KafkaBridgeProperties.Processing(2)
        );
        JsonMessageParser shallowParser = new JsonMessageParser(shallowProperties);

        assertThatThrownBy(() -> shallowParser.parse("{\"a\":{\"b\":{\"c\":1}}}"))
                .isInstanceOf(MessageProcessingException.class)
                .hasMessage("Source Kafka message is not valid JSON");
    }
}
