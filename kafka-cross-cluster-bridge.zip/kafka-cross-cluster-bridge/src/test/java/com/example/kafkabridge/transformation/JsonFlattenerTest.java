package com.example.kafkabridge.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.BinaryNode;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class JsonFlattenerTest {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final JsonFlattener flattener = new JsonFlattener();

    @Test
    void flattensNestedObjectsArraysAndAllCommonScalarTypes() throws Exception {
        JsonNode source = objectMapper.readTree("""
                {
                  "id": 123,
                  "active": true,
                  "ratio": 12.50,
                  "name": "sample",
                  "missing": null,
                  "consumer": {
                    "id": "C1",
                    "details": {"value": 9}
                  },
                  "items": [
                    {"code": "A"},
                    {"code": "B"}
                  ],
                  "emptyObject": {},
                  "emptyArray": []
                }
                """);

        Map<String, Object> result = flattener.flatten(source);

        assertThat(result)
                .containsEntry("id", 123)
                .containsEntry("active", true)
                .containsEntry("ratio", new BigDecimal("12.50"))
                .containsEntry("name", "sample")
                .containsEntry("missing", null)
                .containsEntry("consumer.id", "C1")
                .containsEntry("consumer.details.value", 9)
                .containsEntry("items[0].code", "A")
                .containsEntry("items[1].code", "B")
                .containsEntry("emptyObject", "{}")
                .containsEntry("emptyArray", "[]");
    }

    @Test
    void supportsRootScalarNullEmptyContainersAndBinaryValues() throws Exception {
        assertThat(flattener.flatten(objectMapper.readTree("\"value\"")))
                .containsEntry("$", "value");
        assertThat(flattener.flatten(objectMapper.readTree("null")))
                .containsEntry("$", null);
        assertThat(flattener.flatten(objectMapper.readTree("{}")))
                .containsEntry("$", "{}");
        assertThat(flattener.flatten(objectMapper.readTree("[]")))
                .containsEntry("$", "[]");
        Map<String, Object> binaryResult = flattener.flatten(BinaryNode.valueOf(new byte[]{1, 2, 3}));
        assertThat((byte[]) binaryResult.get("$")).containsExactly(1, 2, 3);
    }

    @Test
    void supportsNullJsonNodeReference() {
        assertThat(flattener.flatten(null)).containsEntry("$", null);
    }

    @Test
    void wrapsBinaryReadFailure() throws Exception {
        JsonNode binaryNode = mock(JsonNode.class);
        when(binaryNode.isNull()).thenReturn(false);
        when(binaryNode.isObject()).thenReturn(false);
        when(binaryNode.isArray()).thenReturn(false);
        when(binaryNode.isTextual()).thenReturn(false);
        when(binaryNode.isBoolean()).thenReturn(false);
        when(binaryNode.isIntegralNumber()).thenReturn(false);
        when(binaryNode.isFloatingPointNumber()).thenReturn(false);
        when(binaryNode.isBinary()).thenReturn(true);
        when(binaryNode.binaryValue()).thenThrow(new IOException("boom"));

        assertThatThrownBy(() -> flattener.flatten(binaryNode))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Unable to read binary JSON value")
                .hasCauseInstanceOf(IOException.class);
    }

    @Test
    void fallsBackToAsTextForUncommonScalarNode() {
        JsonNode node = mock(JsonNode.class);
        when(node.isNull()).thenReturn(false);
        when(node.isObject()).thenReturn(false);
        when(node.isArray()).thenReturn(false);
        when(node.isTextual()).thenReturn(false);
        when(node.isBoolean()).thenReturn(false);
        when(node.isIntegralNumber()).thenReturn(false);
        when(node.isFloatingPointNumber()).thenReturn(false);
        when(node.isBinary()).thenReturn(false);
        when(node.asText()).thenReturn("fallback");

        assertThat(flattener.flatten(node)).containsEntry("$", "fallback");
    }
}
