package com.example.kafkabridge;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;

import static org.mockito.Mockito.mockStatic;

class KafkaBridgeApplicationTest {

    @Test
    void delegatesStartupToSpringApplication() {
        String[] args = {"--sample=value"};

        try (MockedStatic<SpringApplication> springApplication = mockStatic(SpringApplication.class)) {
            KafkaBridgeApplication.main(args);

            springApplication.verify(() -> SpringApplication.run(KafkaBridgeApplication.class, args));
        }
    }
}
