package com.example.kafkabridge.consumer;

import com.example.kafkabridge.producer.KafkaMessageProducer;
import com.example.kafkabridge.transformation.MessageTransformationService;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.support.Acknowledgment;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class KafkaMessageConsumerTest {

    @Test
    void transformsPublishesAndAcknowledgesInThatOrder() {
        MessageTransformationService transformationService = mock(MessageTransformationService.class);
        KafkaMessageProducer producer = mock(KafkaMessageProducer.class);
        Acknowledgment acknowledgment = mock(Acknowledgment.class);
        GenericRecord transformed = mock(GenericRecord.class);
        RecordMetadata metadata = mock(RecordMetadata.class);
        ConsumerRecord<String, String> record =
                new ConsumerRecord<>("source-topic", 2, 15L, "source-key", "{\"id\":1}");

        when(transformationService.transform(record.value())).thenReturn(transformed);
        when(producer.publish(record.key(), transformed)).thenReturn(metadata);
        when(metadata.topic()).thenReturn("destination-topic");
        when(metadata.partition()).thenReturn(1);
        when(metadata.offset()).thenReturn(44L);

        KafkaMessageConsumer consumer = new KafkaMessageConsumer(transformationService, producer);
        consumer.consume(record, acknowledgment);

        var ordered = inOrder(transformationService, producer, acknowledgment);
        ordered.verify(transformationService).transform(record.value());
        ordered.verify(producer).publish(record.key(), transformed);
        ordered.verify(acknowledgment).acknowledge();
    }

    @Test
    void doesNotAcknowledgeWhenTransformationFails() {
        MessageTransformationService transformationService = mock(MessageTransformationService.class);
        KafkaMessageProducer producer = mock(KafkaMessageProducer.class);
        Acknowledgment acknowledgment = mock(Acknowledgment.class);
        ConsumerRecord<String, String> record =
                new ConsumerRecord<>("source-topic", 0, 1L, "key", "bad");

        when(transformationService.transform("bad"))
                .thenThrow(new IllegalArgumentException("transform failed"));

        KafkaMessageConsumer consumer = new KafkaMessageConsumer(transformationService, producer);

        assertThatThrownBy(() -> consumer.consume(record, acknowledgment))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("transform failed");

        verify(producer, never()).publish(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
        verify(acknowledgment, never()).acknowledge();
    }

    @Test
    void doesNotAcknowledgeWhenDestinationPublishFails() {
        MessageTransformationService transformationService = mock(MessageTransformationService.class);
        KafkaMessageProducer producer = mock(KafkaMessageProducer.class);
        Acknowledgment acknowledgment = mock(Acknowledgment.class);
        GenericRecord transformed = mock(GenericRecord.class);
        ConsumerRecord<String, String> record =
                new ConsumerRecord<>("source-topic", 0, 1L, "key", "{\"id\":1}");

        when(transformationService.transform(record.value())).thenReturn(transformed);
        when(producer.publish(record.key(), transformed))
                .thenThrow(new IllegalStateException("publish failed"));

        KafkaMessageConsumer consumer = new KafkaMessageConsumer(transformationService, producer);

        assertThatThrownBy(() -> consumer.consume(record, acknowledgment))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("publish failed");

        verify(acknowledgment, never()).acknowledge();
    }
}
