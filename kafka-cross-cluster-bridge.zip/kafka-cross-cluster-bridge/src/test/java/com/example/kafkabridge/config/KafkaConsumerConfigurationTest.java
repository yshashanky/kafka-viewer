package com.example.kafkabridge.config;

import com.example.kafkabridge.TestFixtures;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class KafkaConsumerConfigurationTest {

    private KafkaBridgeProperties properties;
    private KafkaConsumerConfiguration configuration;

    @BeforeEach
    void setUp() {
        properties = TestFixtures.properties();
        configuration = new KafkaConsumerConfiguration(
                properties,
                new KafkaSslConfigurer(properties)
        );
    }

    @Test
    void createsSourceConsumerFactoryWithExpectedSettings() {
        ConsumerFactory<String, String> factory = configuration.sourceConsumerFactory();

        assertThat(factory).isInstanceOf(DefaultKafkaConsumerFactory.class);
        Map<String, Object> config = ((DefaultKafkaConsumerFactory<String, String>) factory)
                .getConfigurationProperties();

        assertThat(config)
                .containsEntry(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "source:9093")
                .containsEntry(ConsumerConfig.GROUP_ID_CONFIG, "source-group")
                .containsEntry(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class)
                .containsEntry(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class)
                .containsEntry(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false)
                .containsEntry(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
                .containsEntry(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 250)
                .containsEntry("security.protocol", "SSL");
    }

    @Test
    void createsConcurrentListenerFactoryForManualImmediateAtLeastOnceCommit() {
        ConsumerFactory<String, String> consumerFactory = mock(ConsumerFactory.class);

        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                configuration.sourceKafkaListenerContainerFactory(consumerFactory);

        assertThat(factory.getContainerProperties().getAckMode())
                .isEqualTo(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        assertThat(factory.getContainerProperties().isSyncCommits()).isTrue();
    }

    @Test
    void createsRetryingErrorHandlerWithoutAckAfterFailure() {
        DefaultErrorHandler errorHandler = configuration.sourceErrorHandler();

        assertThat(errorHandler).isNotNull();
        assertThat(errorHandler.isAckAfterHandle()).isFalse();
    }
}
