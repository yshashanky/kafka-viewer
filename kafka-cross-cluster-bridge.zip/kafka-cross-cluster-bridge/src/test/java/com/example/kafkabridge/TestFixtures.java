package com.example.kafkabridge;

import com.example.kafkabridge.config.KafkaBridgeProperties;

import java.time.Duration;

public final class TestFixtures {

    private TestFixtures() {
    }

    public static KafkaBridgeProperties properties() {
        return new KafkaBridgeProperties(
                new KafkaBridgeProperties.Ssl(
                        "SSL",
                        "/tmp/truststore.jks",
                        "trust-password",
                        "JKS",
                        "/tmp/keystore.jks",
                        "key-password-store",
                        "JKS",
                        "private-key-password",
                        "https"
                ),
                new KafkaBridgeProperties.Consumer(
                        "source:9093",
                        "source-topic",
                        "source-group",
                        3,
                        250,
                        "earliest",
                        Duration.ofMillis(25)
                ),
                new KafkaBridgeProperties.Producer(
                        "destination:9093",
                        "destination-topic",
                        Duration.ofMillis(100),
                        30_000,
                        120_000,
                        5,
                        5
                ),
                new KafkaBridgeProperties.SchemaRegistry(
                        "https://schema-registry:8081",
                        false,
                        true
                ),
                new KafkaBridgeProperties.Processing(100)
        );
    }
}
