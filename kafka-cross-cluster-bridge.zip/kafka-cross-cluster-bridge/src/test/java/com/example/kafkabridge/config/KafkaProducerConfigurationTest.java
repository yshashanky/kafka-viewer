package com.example.kafkabridge.config;

import com.example.kafkabridge.TestFixtures;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class KafkaProducerConfigurationTest {

    private KafkaProducerConfiguration configuration;

    @BeforeEach
    void setUp() {
        KafkaBridgeProperties properties = TestFixtures.properties();
        configuration = new KafkaProducerConfiguration(
                properties,
                new KafkaSslConfigurer(properties)
        );
    }

    @Test
    void createsDestinationProducerFactoryWithReliabilityAndSchemaRegistrySettings() {
        ProducerFactory<String, GenericRecord> factory = configuration.destinationProducerFactory();

        assertThat(factory).isInstanceOf(DefaultKafkaProducerFactory.class);
        Map<String, Object> config = ((DefaultKafkaProducerFactory<String, GenericRecord>) factory)
                .getConfigurationProperties();

        assertThat(config)
                .containsEntry(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "destination:9093")
                .containsEntry(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class)
                .containsEntry(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class)
                .containsEntry(ProducerConfig.ACKS_CONFIG, "all")
                .containsEntry(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true)
                .containsEntry(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE)
                .containsEntry(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5)
                .containsEntry(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, 30_000)
                .containsEntry(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 120_000)
                .containsEntry(ProducerConfig.LINGER_MS_CONFIG, 5)
                .containsEntry(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG,
                        "https://schema-registry:8081")
                .containsEntry(AbstractKafkaSchemaSerDeConfig.AUTO_REGISTER_SCHEMAS, false)
                .containsEntry(AbstractKafkaSchemaSerDeConfig.USE_LATEST_VERSION, true)
                .containsEntry("security.protocol", "SSL");
    }

    @Test
    void createsKafkaTemplateFromDestinationFactory() {
        ProducerFactory<String, GenericRecord> factory = mock(ProducerFactory.class);

        KafkaTemplate<String, GenericRecord> template =
                configuration.destinationKafkaTemplate(factory);

        assertThat(template).isNotNull();
    }
}
