package com.example.kafkabridge.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;

@Validated
@ConfigurationProperties(prefix = "app.kafka")
public record KafkaBridgeProperties(
        @Valid @NotNull Ssl ssl,
        @Valid @NotNull Consumer consumer,
        @Valid @NotNull Producer producer,
        @Valid @NotNull SchemaRegistry schemaRegistry,
        @Valid @NotNull Processing processing
) {
    public record Ssl(
            @NotBlank String securityProtocol,
            @NotBlank String truststoreLocation,
            @NotBlank String truststorePassword,
            @NotBlank String truststoreType,
            @NotBlank String keystoreLocation,
            @NotBlank String keystorePassword,
            @NotBlank String keystoreType,
            @NotBlank String keyPassword,
            @NotNull String endpointIdentificationAlgorithm
    ) {
    }

    public record Consumer(
            @NotBlank String bootstrapServers,
            @NotBlank String topic,
            @NotBlank String groupId,
            @Min(1) int concurrency,
            @Min(1) int maxPollRecords,
            @NotBlank String autoOffsetReset,
            @NotNull Duration retryInterval
    ) {
    }

    public record Producer(
            @NotBlank String bootstrapServers,
            @NotBlank String topic,
            @NotNull Duration sendTimeout,
            @Min(1) int requestTimeoutMs,
            @Min(1) int deliveryTimeoutMs,
            @Min(1) @Max(5) int maxInFlightRequests,
            @Min(0) int lingerMs
    ) {
    }

    public record SchemaRegistry(
            @NotBlank String url,
            boolean autoRegisterSchemas,
            boolean useLatestVersion
    ) {
    }

    public record Processing(
            @Min(1) int maxJsonDepth
    ) {
    }
}
