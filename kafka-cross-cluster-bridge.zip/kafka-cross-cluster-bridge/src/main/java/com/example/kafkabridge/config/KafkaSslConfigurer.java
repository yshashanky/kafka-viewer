package com.example.kafkabridge.config;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public final class KafkaSslConfigurer {

    private final KafkaBridgeProperties properties;

    public KafkaSslConfigurer(KafkaBridgeProperties properties) {
        this.properties = properties;
    }

    public void applyTo(Map<String, Object> clientProperties) {
        KafkaBridgeProperties.Ssl ssl = properties.ssl();

        clientProperties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, ssl.securityProtocol());
        clientProperties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ssl.truststoreLocation());
        clientProperties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ssl.truststorePassword());
        clientProperties.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, ssl.truststoreType());
        clientProperties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ssl.keystoreLocation());
        clientProperties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ssl.keystorePassword());
        clientProperties.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, ssl.keystoreType());
        clientProperties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, ssl.keyPassword());
        clientProperties.put(
                SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG,
                ssl.endpointIdentificationAlgorithm()
        );
    }
}
