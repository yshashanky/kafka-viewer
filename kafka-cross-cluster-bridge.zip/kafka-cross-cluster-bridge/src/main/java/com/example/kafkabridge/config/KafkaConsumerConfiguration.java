package com.example.kafkabridge.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

@Configuration(proxyBeanMethods = false)
public class KafkaConsumerConfiguration {

    private final KafkaBridgeProperties properties;
    private final KafkaSslConfigurer sslConfigurer;

    public KafkaConsumerConfiguration(
            KafkaBridgeProperties properties,
            KafkaSslConfigurer sslConfigurer
    ) {
        this.properties = properties;
        this.sslConfigurer = sslConfigurer;
    }

    @Bean
    public ConsumerFactory<String, String> sourceConsumerFactory() {
        KafkaBridgeProperties.Consumer consumer = properties.consumer();

        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumer.bootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, consumer.groupId());
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumer.autoOffsetReset());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, consumer.maxPollRecords());

        sslConfigurer.applyTo(config);
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean(name = "sourceKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> sourceKafkaListenerContainerFactory(
            ConsumerFactory<String, String> sourceConsumerFactory
    ) {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();

        factory.setConsumerFactory(sourceConsumerFactory);
        factory.setConcurrency(properties.consumer().concurrency());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.getContainerProperties().setSyncCommits(true);
        factory.setCommonErrorHandler(sourceErrorHandler());
        return factory;
    }

    /**
     * No-loss default: retry a failed source record indefinitely.
     *
     * This intentionally favors at-least-once delivery over availability for a poison record.
     * In a real deployment, introduce an explicitly designed retry/DLQ policy before changing
     * this to a finite retry count.
     */
    @Bean
    public DefaultErrorHandler sourceErrorHandler() {
        long retryIntervalMs = properties.consumer().retryInterval().toMillis();
        DefaultErrorHandler errorHandler = new DefaultErrorHandler(
                new FixedBackOff(retryIntervalMs, FixedBackOff.UNLIMITED_ATTEMPTS)
        );
        errorHandler.setAckAfterHandle(false);
        return errorHandler;
    }
}
