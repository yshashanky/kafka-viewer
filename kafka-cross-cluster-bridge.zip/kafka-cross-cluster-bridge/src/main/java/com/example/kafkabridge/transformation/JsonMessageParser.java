package com.example.kafkabridge.transformation;

import com.example.kafkabridge.config.KafkaBridgeProperties;
import com.example.kafkabridge.exception.MessageProcessingException;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.StreamReadConstraints;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class JsonMessageParser {

    private final ObjectMapper objectMapper;

    public JsonMessageParser(KafkaBridgeProperties properties) {
        StreamReadConstraints constraints = StreamReadConstraints.builder()
                .maxNestingDepth(properties.processing().maxJsonDepth())
                .build();

        JsonFactory jsonFactory = JsonFactory.builder()
                .streamReadConstraints(constraints)
                .build();

        this.objectMapper = new ObjectMapper(jsonFactory);
    }

    public JsonNode parse(String message) {
        if (message == null || message.isBlank()) {
            throw new MessageProcessingException("Source Kafka message is null or blank");
        }

        try {
            return objectMapper.readTree(message);
        } catch (JsonProcessingException exception) {
            throw new MessageProcessingException("Source Kafka message is not valid JSON", exception);
        }
    }
}
