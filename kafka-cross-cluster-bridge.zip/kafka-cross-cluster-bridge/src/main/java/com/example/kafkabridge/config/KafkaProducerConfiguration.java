package com.example.kafkabridge.config;

import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration(proxyBeanMethods = false)
public class KafkaProducerConfiguration {

    private final KafkaBridgeProperties properties;
    private final KafkaSslConfigurer sslConfigurer;

    public KafkaProducerConfiguration(
            KafkaBridgeProperties properties,
            KafkaSslConfigurer sslConfigurer
    ) {
        this.properties = properties;
        this.sslConfigurer = sslConfigurer;
    }

    @Bean
    public ProducerFactory<String, GenericRecord> destinationProducerFactory() {
        KafkaBridgeProperties.Producer producer = properties.producer();
        KafkaBridgeProperties.SchemaRegistry schemaRegistry = properties.schemaRegistry();

        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, producer.bootstrapServers());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);

        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        config.put(
                ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION,
                producer.maxInFlightRequests()
        );
        config.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, producer.requestTimeoutMs());
        config.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, producer.deliveryTimeoutMs());
        config.put(ProducerConfig.LINGER_MS_CONFIG, producer.lingerMs());

        config.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry.url());
        config.put(
                AbstractKafkaSchemaSerDeConfig.AUTO_REGISTER_SCHEMAS,
                schemaRegistry.autoRegisterSchemas()
        );
        config.put(
                AbstractKafkaSchemaSerDeConfig.USE_LATEST_VERSION,
                schemaRegistry.useLatestVersion()
        );

        sslConfigurer.applyTo(config);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, GenericRecord> destinationKafkaTemplate(
            ProducerFactory<String, GenericRecord> destinationProducerFactory
    ) {
        return new KafkaTemplate<>(destinationProducerFactory);
    }
}
