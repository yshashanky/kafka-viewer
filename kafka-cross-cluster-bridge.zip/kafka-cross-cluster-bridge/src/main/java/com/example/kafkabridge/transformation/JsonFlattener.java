package com.example.kafkabridge.transformation;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class JsonFlattener {

    private static final String ROOT_VALUE_KEY = "$";

    /**
     * Flattens arbitrary JSON while preserving array indexes.
     *
     * Examples:
     * consumer.id -> "123"
     * consumers[0].id -> "123"
     *
     * A root scalar is stored under "$". Empty objects/arrays are retained as their JSON text
     * so their presence is not silently lost.
     */
    public Map<String, Object> flatten(JsonNode root) {
        Map<String, Object> flattened = new LinkedHashMap<>();
        flattenNode(root, "", flattened);
        return flattened;
    }

    private void flattenNode(JsonNode node, String path, Map<String, Object> target) {
        if (node == null || node.isNull()) {
            target.put(normalizePath(path), null);
            return;
        }

        if (node.isObject()) {
            if (node.isEmpty()) {
                target.put(normalizePath(path), node.toString());
                return;
            }

            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> field = fields.next();
                String childPath = path.isEmpty() ? field.getKey() : path + "." + field.getKey();
                flattenNode(field.getValue(), childPath, target);
            }
            return;
        }

        if (node.isArray()) {
            if (node.isEmpty()) {
                target.put(normalizePath(path), node.toString());
                return;
            }

            for (int index = 0; index < node.size(); index++) {
                String childPath = path + "[" + index + "]";
                flattenNode(node.get(index), childPath, target);
            }
            return;
        }

        target.put(normalizePath(path), scalarValue(node));
    }

    private Object scalarValue(JsonNode node) {
        if (node.isTextual()) {
            return node.textValue();
        }
        if (node.isBoolean()) {
            return node.booleanValue();
        }
        if (node.isIntegralNumber()) {
            return node.numberValue();
        }
        if (node.isFloatingPointNumber()) {
            return node.decimalValue();
        }
        if (node.isBinary()) {
            try {
                return node.binaryValue();
            } catch (Exception exception) {
                throw new IllegalArgumentException("Unable to read binary JSON value", exception);
            }
        }
        return node.asText();
    }

    private String normalizePath(String path) {
        return path.isEmpty() ? ROOT_VALUE_KEY : path;
    }
}
