package com.example.kafkabridge.producer;

import com.example.kafkabridge.config.KafkaBridgeProperties;
import com.example.kafkabridge.exception.KafkaPublishException;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class KafkaMessageProducer {

    private final KafkaTemplate<String, GenericRecord> kafkaTemplate;
    private final KafkaBridgeProperties properties;

    public KafkaMessageProducer(
            KafkaTemplate<String, GenericRecord> destinationKafkaTemplate,
            KafkaBridgeProperties properties
    ) {
        this.kafkaTemplate = destinationKafkaTemplate;
        this.properties = properties;
    }

    /**
     * Waits for the broker acknowledgment before returning so the source offset can be
     * acknowledged on the same listener thread only after the destination write succeeds.
     */
    public RecordMetadata publish(String key, GenericRecord record) {
        try {
            SendResult<String, GenericRecord> result = kafkaTemplate
                    .send(properties.producer().topic(), key, record)
                    .get(properties.producer().sendTimeout().toMillis(), TimeUnit.MILLISECONDS);

            return result.getRecordMetadata();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new KafkaPublishException("Interrupted while publishing to destination Kafka", exception);
        } catch (ExecutionException | TimeoutException exception) {
            throw new KafkaPublishException("Failed to publish to destination Kafka", exception);
        }
    }
}
