package com.example.kafkabridge.transformation;

import com.example.kafkabridge.exception.MessageProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.avro.generic.GenericRecord;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class MessageTransformationService {

    private final JsonMessageParser jsonMessageParser;
    private final JsonFlattener jsonFlattener;

    public MessageTransformationService(
            JsonMessageParser jsonMessageParser,
            JsonFlattener jsonFlattener
    ) {
        this.jsonMessageParser = jsonMessageParser;
        this.jsonFlattener = jsonFlattener;
    }

    /**
     * Transformation entry point called by the Kafka consumer.
     *
     * The generic parsing/flattening is intentionally implemented, but construction of the
     * destination GenericRecord is intentionally left schema-specific. Implement the final
     * mapping once the destination Avro schema and business mapping rules are available.
     */
    public GenericRecord transform(String inputJson) {
        JsonNode source = jsonMessageParser.parse(inputJson);
        Map<String, Object> flattened = jsonFlattener.flatten(source);

        return buildDestinationRecord(source, flattened);
    }

    private GenericRecord buildDestinationRecord(
            JsonNode source,
            Map<String, Object> flattened
    ) {
        // TODO: Apply business mapping and create the destination Avro GenericRecord here.
        // Both the original dynamic JsonNode and flattened map are available so mapping code
        // does not have to re-parse the source payload.
        throw new MessageProcessingException(
                "Destination GenericRecord transformation is not implemented yet"
        );
    }
}
