package com.example.kafkabridge.consumer;

import com.example.kafkabridge.producer.KafkaMessageProducer;
import com.example.kafkabridge.transformation.MessageTransformationService;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
public class KafkaMessageConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaMessageConsumer.class);

    private final MessageTransformationService transformationService;
    private final KafkaMessageProducer producer;

    public KafkaMessageConsumer(
            MessageTransformationService transformationService,
            KafkaMessageProducer producer
    ) {
        this.transformationService = transformationService;
        this.producer = producer;
    }

    @KafkaListener(
            topics = "${app.kafka.consumer.topic}",
            groupId = "${app.kafka.consumer.group-id}",
            containerFactory = "sourceKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> sourceRecord, Acknowledgment acknowledgment) {
        GenericRecord transformedRecord = transformationService.transform(sourceRecord.value());
        RecordMetadata destinationMetadata = producer.publish(sourceRecord.key(), transformedRecord);

        // Commit the source offset only after the destination broker has acknowledged the write.
        acknowledgment.acknowledge();

        LOGGER.debug(
                "Processed source topic={} partition={} offset={} -> destination topic={} partition={} offset={}",
                sourceRecord.topic(),
                sourceRecord.partition(),
                sourceRecord.offset(),
                destinationMetadata.topic(),
                destinationMetadata.partition(),
                destinationMetadata.offset()
        );
    }
}
